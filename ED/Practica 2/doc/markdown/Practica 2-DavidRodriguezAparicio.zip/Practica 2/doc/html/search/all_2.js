var searchData=
[
  ['detectarfranjaslibrespordia_0',['detectarFranjasLibresPorDia',['../class_agenda_eventos.html#a4ad5007abbba76026745a0724c992edb',1,'AgendaEventos']]]
];
