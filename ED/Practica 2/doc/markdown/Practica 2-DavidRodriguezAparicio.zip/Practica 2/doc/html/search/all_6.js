var searchData=
[
  ['resumensemanal_0',['resumenSemanal',['../class_agenda_eventos.html#a9106c1b6d62b82b1b341ce43b5823d46',1,'AgendaEventos']]]
];
