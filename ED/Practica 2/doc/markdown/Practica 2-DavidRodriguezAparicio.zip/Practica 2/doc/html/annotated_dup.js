var annotated_dup =
[
    [ "AgendaEventos", "class_agenda_eventos.html", "class_agenda_eventos" ],
    [ "Evento", "class_evento.html", "class_evento" ]
];