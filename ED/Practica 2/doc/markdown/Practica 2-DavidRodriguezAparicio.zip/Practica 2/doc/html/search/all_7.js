var searchData=
[
  ['setcapacidad_0',['setCapacidad',['../class_agenda_eventos.html#ac538a4b36e113a4a70b246aeb2a585b8',1,'AgendaEventos']]],
  ['setdia_1',['setDia',['../class_evento.html#a8b0cc6f3e008e2c170d596425dbb0116',1,'Evento']]],
  ['sethorafin_2',['setHoraFin',['../class_evento.html#a5b50b9a640c6f24b9ea640c1412c4289',1,'Evento']]],
  ['sethorainicio_3',['setHoraInicio',['../class_evento.html#acbf3ade07779dc3d413f922b37b8c249',1,'Evento']]],
  ['setnombre_4',['setNombre',['../class_evento.html#a4d341045ed21f236419530fa663b8847',1,'Evento']]],
  ['setnumeventos_5',['setNumEventos',['../class_agenda_eventos.html#afbd9188274cf9ed566ef39c33c3a9766',1,'AgendaEventos']]]
];
