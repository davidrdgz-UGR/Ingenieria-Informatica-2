package civitas;

public enum SalidasCarcel {
    PAGANDO,
    TIRANDO
}
