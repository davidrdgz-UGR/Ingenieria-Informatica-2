package civitas;

public enum GestionInmobilarias {
    VENDER,
    HIPOTECAR,
    CANCELAR_HIPOTECA,
    CONSTRUIR_CASA,
    CONSTRUIR_HOTEL,
    TERMINAR
}
