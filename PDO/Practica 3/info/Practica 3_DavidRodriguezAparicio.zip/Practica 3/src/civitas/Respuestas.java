package civitas;

public enum Respuestas {
    SI,
    NO
}
