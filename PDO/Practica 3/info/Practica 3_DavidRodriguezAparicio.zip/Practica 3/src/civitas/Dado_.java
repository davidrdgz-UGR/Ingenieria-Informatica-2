package civitas;

public class Dado_ {
    
}
