package civitas;

public enum OperacionesJuego {
    PASAR_TURNO,
    SALIR_CARCEL,
    AVANZAR,
    COMPRAR,
    GESTIONAR
}
