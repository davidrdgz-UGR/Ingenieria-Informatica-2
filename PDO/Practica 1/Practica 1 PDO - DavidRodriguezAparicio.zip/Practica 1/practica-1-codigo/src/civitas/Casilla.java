package civitas;

public class Casilla {
    
    private String nombre;


    /* Constructor */
    Casilla(String nombre) {
        this.nombre = nombre;
    }

    


    /* GETTERS / SETTERS */
    String getNombre() {
        return nombre;
    }

}
